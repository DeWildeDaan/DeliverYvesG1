namespace DeliverYves.Models;
public class Row
{
    public int TakenLeft { get; set; }
    public int TakenRight { get; set; }
    public List<string>? Drinks { get; set; }
}