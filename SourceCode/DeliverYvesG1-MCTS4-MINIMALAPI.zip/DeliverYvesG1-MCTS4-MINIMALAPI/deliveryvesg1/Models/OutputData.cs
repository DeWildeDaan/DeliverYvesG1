namespace DeliverYves.Models;
public class OutputData
{
    public string? RackId { get; set; }
    public string? CustomerId { get; set; }
    public int Total { get; set;}
    public Row Row1 { get; set;}
    public Row Row2 { get; set;}
    public Row Row3 { get; set;}
    public Row Row4 { get; set;}
}