namespace DeliverYves.Models;
public class TotalPredictions
{
    public string? CustomerId { get; set; }
    public string? Name { get; set; }
    public int? Total { get; set; }
}