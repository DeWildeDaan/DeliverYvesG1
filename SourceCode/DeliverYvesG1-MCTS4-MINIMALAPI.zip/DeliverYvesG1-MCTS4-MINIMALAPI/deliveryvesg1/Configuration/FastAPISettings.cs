namespace DeliverYves.Configuration;
public class FastAPISettings
{
    public string? Uri { get; set; }
}