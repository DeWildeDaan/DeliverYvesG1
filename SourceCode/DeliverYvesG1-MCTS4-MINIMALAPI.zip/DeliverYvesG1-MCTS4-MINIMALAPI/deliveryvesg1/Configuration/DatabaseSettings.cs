namespace DeliverYves.Configuration;
public class DatabaseSettings
{
    public string? Uri { get; set; }
    public string? TableR { get; set; }
    public string? TableP { get; set; }
    public string? TableS { get; set; }
    public string? Account { get; set; }
    public string? Key { get; set; }
}